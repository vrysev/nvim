---@type LazySpec
return {
  "sample-usr/rakis.nvim",
  name = "rakis",
}
