---@type LazySpec
return {
 "morhetz/gruvbox",
 name = "gruvbox",
}
